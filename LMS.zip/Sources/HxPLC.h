#pragma once
class HxPLC
{
public:
    bool SetEnable( bool en );
    bool SetMarkResult( bool status );
    bool SetCvWidth( double width );
    bool SetTransferMode( bool on );
    bool SetStopper( int stopper );
    bool IsHasTrigger();
    bool ConfirmTrigger();
    bool SetCompleteBit();
};

HxPLC* PLC();