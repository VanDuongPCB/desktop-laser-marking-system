#pragma once
#include "QString"
#include "QDir"
#include "QFile"
#include "QFileInfo"
#include "QSettings"

class HxFileManager;
using HxFileManagerPtr = std::shared_ptr<HxFileManager>;

using HxRegSettings = QSettings;
using HxRegSettingsPtr = std::shared_ptr<QSettings>;

class HxFileManager
{
public:
    enum FileType
    {
        eApplicationDir,
        eDBRootDir,
        eDBOldRootDir,
        eDBProfiles,
        eDBDesigns,
        eDBModels,
        eDBPlans,
        eDBHardware,
        eDBData,
        eDefaultFilesDir
    };

    enum SettingType
    {
        eSettingData,
        eSettingLicense,
        eSettingTheme
    };

    HxFileManager();
    QString GetPath( FileType fileType ) const;
    QStringList GetFilesAndFolders( const QString& path, QDir::Filters filters = QDir::Dirs | QDir::Files ) const;
    HxRegSettingsPtr GetSettings( SettingType type ) const;
    static HxFileManagerPtr Create();

    QString DataBaseFilePath() const;
    QString IVProgramDir() const;

    bool SetDataBaseFilePath(const QString& path);
    bool SetIVProgramDir( const QString& path );
};


HxFileManager* FileManager();