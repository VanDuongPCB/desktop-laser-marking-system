#pragma once
#include "QString"

class HxBarcodeSaver
{
public:
    static void Save( QString code );
};

