#include "HxLoginDialog.h"
#include "ui_hxlogindialog.h"
#include "HxProtector.h"

HxLoginDialog::HxLoginDialog( QWidget* parent ) : QDialog( parent ), ui( new Ui::LoginDialog )
{
    ui->setupUi( this );

    auto profiles = ProfileManager()->Profiles();
    for ( auto &profile : profiles )
    {
        ui->cbxProfile->addItem( profile->ID() );
    }
    ui->cbxProfile->setFocus();
}

HxLoginDialog::~HxLoginDialog()
{
    delete ui;
}

bool HxLoginDialog::CheckInputs()
{
    QString user = ui->cbxProfile->currentText().trimmed().toUpper();
    QString pass = ui->txtPassword->text().trimmed();
    return user.length() > 0 && pass.length() > 0;
}

void HxLoginDialog::on_txtUserName_textChanged( const QString& arg1 )
{
    ui->btnLogin->setEnabled( CheckInputs() );
}

void HxLoginDialog::on_txtPassword_textChanged( const QString& arg1 )
{
    ui->btnLogin->setEnabled( CheckInputs() );
}

void HxLoginDialog::on_btnLogin_clicked()
{
    QString user = ui->cbxProfile->currentText().trimmed().toLower();
    QString pass = ui->txtPassword->text().trimmed();
    if ( Protector()->Login(user, pass) )
    {
        this->close();
        this->setResult( 1 );
    }
}
