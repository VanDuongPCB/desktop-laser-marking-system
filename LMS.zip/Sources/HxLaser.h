#pragma once
#include "QString"
#include "QMap"

#include "HxPosition.h"
#include "HxDesign.h"
#include "HxStopper.h"

class HxLaserMachine
{
private:
    bool DetectPortExisting();
    QString SendData( const QString& data, int timeout = 30000 );
    QString DetectError( const QString& data );

public:
    bool SetProgram( const QString& name );
    bool SetupBlockData( const QString& program, std::map<int, QString> dataMap );
    bool SetupPosition( const QString& program, HxPosition pos, int stopper, HxDesign design );
    bool Burn();
};

HxLaserMachine* GetLaserMachine();
