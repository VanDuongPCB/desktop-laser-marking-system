#pragma once

#include "HxDesign.h"
#include "HxModel.h"
#include "HxLOT.h"


class HxDataGenerator
{
public:
    QString Gen( const QString& format, HxLOTPtr pLOT, HxModelPtr pModel );
    std::map<int, QString> Gen( HxDesignPtr pDesign, HxLOTPtr pLOT, HxModelPtr pModel );
};