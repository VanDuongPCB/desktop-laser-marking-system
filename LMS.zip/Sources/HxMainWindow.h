#pragma once
#include <QMainWindow>
#include "HxException.h"

namespace Ui
{
    class MainWindow;
}

class HxMainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit HxMainWindow( QWidget* parent = 0 );
    ~HxMainWindow();
private slots:
    void ErrorReported( HxException ex );

private:
    Ui::MainWindow* ui;
    std::vector<QAction*> actions;
    std::vector<QWidget*> pages;

    int m_currentTabIndex = 0;

    void showEvent( QShowEvent* );
    void closeEvent( QCloseEvent* );
    bool eventFilter( QObject*, QEvent* );
    void OnReDrawTab();
    void OnUpdateTabEnabled();
    void OnLoginOrLogout();
    void OnLockUI();
    void OnUnLockUIForSuper();
    void OnUnLockUIForAdmin();
    void OnTabChanged( int index );
};

