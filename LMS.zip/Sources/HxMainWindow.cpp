#include "HxMainWindow.h"
#include "ui_hxmainwindow.h"

#include "QSignalBlocker";

#include "HxSettingsWindow.h"
#include "HxMarkWindow.h"
#include "HxControlWindow.h"
#include "HxModelWindow.h"
#include "HxLOTWindow.h"
#include "HxDesignWindow.h"
#include "HxTransferWindow.h"
#include "HxLoginDialog.h"

#include "HxProtector.h"
#include "HxMessage.h"
#include "HxEvent.h"
#include "HxSystemError.h"



HxMainWindow::HxMainWindow( QWidget* parent ) : QMainWindow( parent ), ui( new Ui::MainWindow )
{
    ui->setupUi( this );

    ui->tabPlans->layout()->addWidget( new HxLOTWindow() );



    qApp->installEventFilter( this );

    m_currentTabIndex = ui->tabWidget->currentIndex();

    connect( HxSystemError::Instance(), &HxSystemError::Reported, this, &HxMainWindow::ErrorReported );

    connect( ui->tabWidget, &QTabWidget::currentChanged, this, &HxMainWindow::OnTabChanged );

    OnReDrawTab();
    OnLockUI();
    setWindowState( Qt::WindowMaximized );
}

HxMainWindow::~HxMainWindow()
{
    delete ui;
}

void HxMainWindow::showEvent( QShowEvent* )
{

}

void HxMainWindow::closeEvent( QCloseEvent* )
{

}

bool HxMainWindow::eventFilter( QObject* watched, QEvent* event )
{
    if ( event->type() != QEvent::User )
        return QMainWindow::eventFilter( watched, event );

    HxEvent* pEvent = static_cast< HxEvent* >( event );
    HxEvent::Type type = pEvent->GetType();

    switch ( type )
    {
    case HxEvent::eLoginEvent:
    {
        HxProfilePtr pProfile = Protector()->Profile();
        if ( !pProfile )
            OnLockUI();
        else if ( pProfile->Permission( "ADMIN" ) )
            OnUnLockUIForAdmin();
        else
            OnUnLockUIForSuper();
    }
    break;
    case HxEvent::eLogoutEvent:
        OnLockUI();
        break;
    default:
        break;
    }

    return true;
}

void HxMainWindow::OnReDrawTab()
{

}

void HxMainWindow::OnUpdateTabEnabled()
{

}

void HxMainWindow::OnLoginOrLogout()
{
    if ( Protector()->Profile() != nullptr )
    {
        int res = HxMsgQuestion( "Bạn có chắc chắn muốn đăng xuất không ?", "Khoan đã" );
        if ( res == QMessageBox::StandardButton::Yes )
            Protector()->Logout();
    }
    else
    {
        HxLoginDialog( this ).exec();
    }
}

void HxMainWindow::OnLockUI()
{
    ui->tabLogin->setEnabled( false );
    ui->tabPlans->setEnabled( false );
    ui->tabModel->setEnabled( false );
    ui->tabDesign->setEnabled( false );
    ui->tabIV->setEnabled( false );
    ui->tabSetting->setEnabled( false );
    ui->tabControl->setEnabled( false );
    OnUpdateTabEnabled();
}

void HxMainWindow::OnUnLockUIForSuper()
{
    ui->tabLogin->setEnabled( false );
    ui->tabPlans->setEnabled( true );
    ui->tabModel->setEnabled( true );
    ui->tabDesign->setEnabled( true );
    ui->tabIV->setEnabled( true );
    OnUpdateTabEnabled();
}

void HxMainWindow::OnUnLockUIForAdmin()
{
    OnUnLockUIForSuper();
    ui->tabSetting->setEnabled( true );
    ui->tabControl->setEnabled( true );
    OnUpdateTabEnabled();
}

void HxMainWindow::OnTabChanged( int index )
{
    if ( !ui->tabWidget->currentWidget()->isEnabled() || index == 0 )
    {
        if ( index == 0 )
            OnLoginOrLogout();

        QSignalBlocker blocker( ui->tabWidget );
        ui->tabWidget->setCurrentIndex( m_currentTabIndex );
        return;
    }

    m_currentTabIndex = index;
}

void HxMainWindow::ErrorReported( HxException ex )
{
    HxMsgError( ex.Message(), ex.Where());
}
