#include "HxLOT.h"

#include "QJsonObject"
#include "QJsonArray"
#include "QJsonDocument"
#include "QFile"
#include "QDir"
#include "QFileInfo"
#include "QFileInfoList"
#include "QCoreApplication"

#include "HxConvert.h"
#include "HxFileManager.h"

HxLOT::HxLOT()
{
    m_comments[ "FIX1" ] = "";
    m_comments[ "FIX2" ] = "";
    m_comments[ "FIX3" ] = "";
    m_comments[ "FIX4" ] = "";
    m_comments[ "FIX5" ] = "";
}

HxLOT::~HxLOT()
{
}

QString HxLOT::Name() const
{
    return m_name;
}

QString HxLOT::CounterStart() const
{
    return m_counterStart;
}

QString HxLOT::CounterEnd() const
{
    int len = m_counterStart.length();
    int start = m_counterStart.toInt( 0 );
    int cnt = start + m_quantity - 1;
    return QString::number( cnt ).rightJustified( len, '0' );
}

QString HxLOT::Counter() const
{
    int len = m_counterStart.length();
    int start = m_counterStart.toInt( 0 );
    int cnt = start + m_progress;
    return QString::number( cnt ).rightJustified( len, '0' );
}

QString HxLOT::MACStart() const
{
    return m_macStart;
}

QString HxLOT::MACEnd() const
{
    return m_macEnd;
}

QString HxLOT::MAC() const
{
    uint64_t start = Uint64FromHexString( m_macStart );
    uint64_t cnt = start + m_progress;
    return HexStringFromUint64( cnt, 12 );
}

int HxLOT::Quantity() const
{
    return m_quantity;
}

int HxLOT::Progress() const
{
    return m_progress;
}

QString HxLOT::Model() const
{
    return m_modelName;
}

QString HxLOT::Value( QString paramName ) const
{
    if ( paramName == "NAME" )
        return m_name.split( "-RE" ).first();
    else if ( paramName == "COUNTER" )
        return Counter();
    else if ( paramName == "MAC" )
        return MAC();
    else
    {
        auto it = m_comments.find( paramName );
        if ( it != m_comments.end() )
            return it->second;
        return "LOT." + paramName;
    }
}

std::map<QString, QString> HxLOT::Comments() const
{
    return m_comments;
}

bool HxLOT::IsCompleted()
{
    Evaluate();
    return m_progress >= m_quantity;
}

HxLOT::ProductStatus HxLOT::Status() const
{
    return m_status;
}

void HxLOT::Evaluate()
{
    if ( m_progress <= 0 )
        m_status = ePending;
    else if ( m_progress < m_quantity )
        m_status = eProduct;
    else
        m_status = eCompleted;
}

void HxLOT::SetName( const QString& value )
{
    Modify( m_name, value, eName );
}

void HxLOT::SetCounterStart( const QString& value )
{
    Modify( m_counterStart, value, eOther );
}

void HxLOT::SetMACStart( const QString& value )
{
    Modify( m_macStart, value, eOther );
}

void HxLOT::SetMACEnd( const QString& value )
{
    Modify( m_macEnd, value, eOther );
}

void HxLOT::SetQuantity( int value )
{
    Modify( m_quantity, value, eOther );
}

void HxLOT::SetProgress( int value )
{
    Modify( m_progress, value, eOther );
}

void HxLOT::SetModel( const QString& value )
{
    Modify( m_modelName, value, eOther );
}

void HxLOT::SetValue( const QString& name, const QString& value )
{
    m_comments[ name ] = value;
    auto it = m_comments.find( name );
    if ( it == m_comments.end() || it->second != value )
    {
        m_comments[ name ] = value;
        SetModified( eOther );
    }
}

bool HxLOT::NextItem()
{
    m_progress++;
    return m_progress < m_quantity;
}

HxLOTPtr HxLOT::Clone() const
{
    auto pClone = LOTManager()->Create();
    *pClone.get() = *this;
    return pClone;
}

HxLOTPtr HxLOTManager::Create()
{
    return std::make_shared<HxLOT>();
}

HxLOTPtr HxLOTManager::GetLOT( const QString& lotName )
{
    //QString dir = FileManager()->GetPath( HxFileManager::eDBLOTDir );
    //QDir().mkdir( dir );
    //QString filePath = dir + "/" + lotName + ".lot";

    //HxLOTPtr pLOT;
    //QFileInfo fileInfo( filePath );
    //QFile fileReader( filePath );
    //if ( !fileReader.open( QIODevice::ReadOnly ) )
    //    return pLOT;

    //QDateTime lastWrite = fileInfo.lastModified();

    //QByteArray json = fileReader.readAll();
    //fileReader.close();

    //QJsonDocument doc = QJsonDocument::fromJson( json );
    //QJsonObject obj = doc.object();

    //if ( !pLOT )
    //    pLOT = Create();

    //pLOT->SetName( fileInfo.baseName().toUpper() );
    //pLOT->SetMACStart( obj.value( "mac-start" ).toString() );
    //pLOT->SetMACEnd( obj.value( "mac-end" ).toString() );
    //pLOT->SetCounterStart( obj.value( "counter-start" ).toString() );
    //pLOT->SetQuantity( obj.value( "quantity" ).toInt() );
    //pLOT->SetProgress( obj.value( "progress" ).toInt( 0 ) );
    //pLOT->SetModel( obj.value( "model" ).toString() );
    //QJsonObject cmtObj = obj.value( "comments" ).toObject();
    //QStringList keys = cmtObj.keys();
    //for ( auto& key : keys )
    //{
    //    pLOT->SetValue( key, cmtObj.value( key ).toString() );
    //    if ( m_paramNames.contains( key ) )
    //        m_paramNames.push_back( key );
    //}

    //int days = lastWrite.daysTo( QDateTime::currentDateTime() );
    //if ( pLOT->Progress() >= pLOT->Quantity() && days >= 45 )
    //{
    //    //QFile( fileInfo.absoluteFilePath() ).remove();
    //    pLOT.reset();
    //}

    //pLOT->ClearModified();
    //pLOT->Evaluate();
    //return pLOT;
    return nullptr;
}

HxLOTPtrMap HxLOTManager::GetLOTs()
{
    HxLOTPtrMap map;
    //QString lotDir = FileManager()->GetPath( HxFileManager::eDBLOTDir );
    //QDir().mkdir( lotDir );
    //QFileInfoList fileInfos = QDir( lotDir ).entryInfoList( { "*.lot" } );
    //for ( auto& fileInfo : fileInfos )
    //{
    //    QString name = fileInfo.baseName().toUpper();
    //    HxLOTPtr pLOT = GetLOT( name );
    //    if ( !pLOT )
    //        continue;

    //    name = QString( "%1_%2" ).arg( pLOT->Status() ).arg( name );
    //    map[ name ] = pLOT;
    //}

    return map;
}

void HxLOTManager::Save( HxLOTPtr pLOT )
{
    if ( !pLOT )
        return;

    //QJsonObject obj;
    //obj.insert( "mac-start", pLOT->MACStart() );
    //obj.insert( "mac-end", pLOT->MACEnd() );
    //obj.insert( "counter-start", pLOT->CounterStart() );
    //obj.insert( "quantity", pLOT->Quantity() );
    //obj.insert( "progress", pLOT->Progress() );
    //obj.insert( "model", pLOT->Model() );

    //QJsonObject commObj;
    //const auto& comments = pLOT->Comments();
    //for ( auto& [key, value] : comments )
    //    commObj.insert( key, value );

    //obj.insert( "comments", commObj );

    //QJsonDocument doc;
    //doc.setObject( obj );

    //QString dir = GetFileManager()->GetPath( HxFileManager::eDBLOTDir );
    //QDir().mkdir( dir );
    //QString filePath = dir + "/" + pLOT->Name() + ".lot";
    //QFile fileWriter( filePath );
    //if ( fileWriter.open( QIODevice::WriteOnly ) )
    //{
    //    fileWriter.write( doc.toJson() );
    //    fileWriter.close();
    //}
}

void HxLOTManager::Removes( const QStringList& names )
{
    //QString dir = GetFileManager()->GetPath( HxFileManager::eDBLOTDir );
    //QDir().mkdir( dir );
    //for ( auto& name : names )
    //{
    //    QString filePath = dir + "/" + name + ".lot";
    //    QFile::remove( filePath );
    //}

}

QStringList HxLOTManager::Parameters()
{
    QStringList items = { "NAME","COUNTER","FIX1","FIX2","FIX3","FIX4","FIX5" };
    std::sort( m_paramNames.begin(), m_paramNames.end() );
    for ( auto& name : m_paramNames )
    {
        if ( items.contains( name ) )
            continue;
        items.push_back( name );
    }
    return items;
}

void HxLOTManager::Migration( const QString& dir )
{
    QString lotDir = dir;
    QDir().mkdir( lotDir );
    QFileInfoList fileInfos = QDir( lotDir ).entryInfoList( { "*.lot" } );
    for ( auto& fileInfo : fileInfos )
    {
        QString name = fileInfo.baseName().toUpper();
        HxLOTPtr pLOT = GetLOT( name );
        if ( !pLOT )
            continue;

        QString lotName = fileInfo.baseName().toUpper();
        QString filePath = dir + "/" + lotName + ".lot";

        QFileInfo fileInfo( filePath );
        QFile fileReader( filePath );
        if ( !fileReader.open( QIODevice::ReadOnly ) )
            continue;

        QDateTime lastWrite = fileInfo.lastModified();

        QByteArray json = fileReader.readAll();
        fileReader.close();

        QJsonDocument doc = QJsonDocument::fromJson( json );
        QJsonObject obj = doc.object();

    //pLOT->SetName( fileInfo.baseName().toUpper() );
    //pLOT->SetMACStart( obj.value( "mac-start" ).toString() );
    //pLOT->SetMACEnd( obj.value( "mac-end" ).toString() );
    //pLOT->SetCounterStart( obj.value( "counter-start" ).toString() );
    //pLOT->SetQuantity( obj.value( "quantity" ).toInt() );
    //pLOT->SetProgress( obj.value( "progress" ).toInt( 0 ) );
    //pLOT->SetModel( obj.value( "model" ).toString() );
    //QJsonObject cmtObj = obj.value( "comments" ).toObject();
    //QStringList keys = cmtObj.keys();
    //for ( auto& key : keys )
    //{
    //    pLOT->SetValue( key, cmtObj.value( key ).toString() );
    //    if ( m_paramNames.contains( key ) )
    //        m_paramNames.push_back( key );
    //}

    //int days = lastWrite.daysTo( QDateTime::currentDateTime() );
    //if ( pLOT->Progress() >= pLOT->Quantity() && days >= 45 )
    //{
    //    //QFile( fileInfo.absoluteFilePath() ).remove();
    //    pLOT.reset();
    //}

    //pLOT->ClearModified();
    //pLOT->Evaluate();
    //return pLOT;
    }
}

HxLOTManager* LOTManager()
{
    static HxLOTManager instance;
    return &instance;
}
