#pragma once
#include "QString"



class HxBarcode
{
public:
    bool IsHasData();
    bool Clear();
    QString Read();
    bool SendFeedback( bool status );
    void Save( const QString& code );
};

HxBarcode* Barcode();