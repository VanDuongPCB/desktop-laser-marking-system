#include "HxMainWindow.h"
#include <QApplication>
#include <QStyleFactory>
#include "HxSettings.h"
#include "HxSettings.h"
#include "HxDesign.h"
#include "HxIVProgram.h"
#include "HxLOT.h"
#include "HxModel.h"
#include "HxProfile.h"
#include "HxStopper.h"
#include "HxMarker.h"
#include "HxLicense.h"

#include "HxDatabase.h"
#include "HxFileManager.h"
#include "HxMigration.h"
#include "HxRegisterDialog.h"




int main( int argc, char* argv[] )
{
    QApplication a( argc, argv );
    a.setStyle( "fusion" );

    bool bIsLicensed = Licensing()->IsRegistered();

    if ( !bIsLicensed )
    {
        HxRegisterDialog licenseDialog;
        if ( licenseDialog.exec() )
            bIsLicensed = true;
    }

    if ( !bIsLicensed )
    {
        return 0;
    }

    HxDatabase::addDatabase( "QSQLITE", "SQLITE");

    Migration()->Run();

    ProfileManager()->Migration();
    ProfileManager()->Profiles();


    HxMainWindow w;
    //HxSettings::load();
    //HxStopper::Load();
    //HxDesign::Load();
    //HxIVProgram::Load();
    //HxModel::Load();
    //HxLOT::Load();
    HxProfile::Load();

    HxMarker::Initialize();

    w.show();
    int code = a.exec();
    HxMarker::Terminate();
    return code;
}
