#include "HxProfile.h"
#include <QCoreApplication>
#include <QDir>
#include <QFile>
#include <QJsonObject>
#include <QJsonArray>
#include <QJsonDocument>
#include "QStringBuilder"

#include "HxDatabase.h"
#include "HxFileManager.h"

HxProfile::HxProfile()
{

}

HxProfile::~HxProfile()
{

}

QString HxProfile::ID() const
{
    return m_id.trimmed().toLower();
}
QString HxProfile::Name() const
{
    return m_name;
}

QString HxProfile::Password() const
{
    return m_password;
}

QString HxProfile::Permissions() const
{
    QStringList items;
    for ( auto& permission : m_permissions )
    {
        items.push_back( permission.trimmed().toUpper() );
    }
    return items.join( "," );
}

bool HxProfile::Permission( const QString& permission ) const
{
    QString permisionName = permission.trimmed().toUpper();
    auto it = m_permissions.find( permisionName );
    return it != m_permissions.end();
}

void HxProfile::SetID( const QString& ID )
{
    Modify( m_id, ID, eCreate );
}
void HxProfile::SetName( const QString& name )
{
    Modify( m_name, name, eUpdate );
}

void HxProfile::SetPassword( const QString& password )
{
    Modify( m_password, password, eUpdate );
}

void HxProfile::SetPermission( const QString& permission, bool isOn )
{
    QString permisionName = permission.trimmed().toUpper();
    if ( permisionName.isEmpty() )
        return;
    if ( isOn )
    {
        auto it = m_permissions.find( permisionName );
        if ( it != m_permissions.end() )
        {
            m_permissions.insert( permisionName );
            SetModified( eUpdate );
        }
    }
    else
    {
        auto it = m_permissions.find( permisionName );
        if ( it != m_permissions.end() )
        {
            m_permissions.erase( permisionName );
            SetModified( eUpdate );
        }
    }
}

/* -------------------------------------------------------- */
std::vector<std::shared_ptr<HxProfile>> HxProfile::items;
void HxProfile::Load()
{
    items.clear();
    QString dir = QCoreApplication::applicationDirPath() + "/settings";
    QDir().mkdir( dir );
    QFile fileReader( dir + "/user.dat" );
    if ( fileReader.open( QIODevice::ReadOnly ) )
    {
        QByteArray json = fileReader.readAll();
        fileReader.close();
        QJsonArray arr = QJsonDocument::fromJson( json ).array();
        for ( auto it : arr )
        {
            QJsonObject obj = it.toObject();
            HxProfile* user = new HxProfile();
            items.emplace_back( user );
            user->name = obj.value( "name" ).toString();
            user->pass = obj.value( "pass" ).toString();
        }
    }
}
void HxProfile::Save()
{
    QString dir = QCoreApplication::applicationDirPath() + "/settings";
    QDir().mkdir( dir );

    QJsonArray arr;
    for ( auto& it : items )
    {
        QJsonObject obj;
        obj.insert( "name", it->name );
        obj.insert( "pass", it->pass );
        arr.push_back( obj );
    }

    QJsonDocument doc;
    doc.setArray( arr );

    QFile fileWriter( dir + "/user.dat" );
    if ( fileWriter.open( QIODevice::WriteOnly ) )
    {
        fileWriter.write( doc.toJson() );
        fileWriter.close();
    }
}



HxProfileManager::HxProfileManager()
{
}

void HxProfileManager::Migration()
{
    QString databaseFile = "D:/LMS/LMS.db";
    if ( QFileInfo( databaseFile ).exists() )
        return;

    // copy
    QString databaseDefault = qApp->applicationDirPath() + "/Default Files/LMS.db";
    QFile::copy( databaseDefault, databaseFile );

    // transfer data
    //QString dir = QCoreApplication::applicationDirPath() + "/settings";
    //QDir().mkdir( dir );
    //QFile fileReader( dir + "/user.dat" );
    //if ( fileReader.open( QIODevice::ReadOnly ) )
    //{
    //    QByteArray json = fileReader.readAll();
    //    fileReader.close();
    //    QJsonArray arr = QJsonDocument::fromJson( json ).array();
    //    for ( auto it : arr )
    //    {
    //        QJsonObject obj = it.toObject();
    //        HxProfile* user = new HxProfile();
    //        items.emplace_back( user );
    //        user->name = obj.value( "name" ).toString();
    //        user->pass = obj.value( "pass" ).toString();
    //    }
    //}
}

HxProfilePtrArray HxProfileManager::Profiles()
{
    HxProfilePtrArray items;

    QString cmd = "SELECT ID, Name, Password, Permissions FROM Profiles ORDER BY name";
    HxDatabase db = HxDatabase::database("SQLITE");
    db.setDatabaseName( FileManager()->DataBaseFilePath() );

    if ( !db.open() )
    {
        return items;
    }

    HxQuery query( db );
    if ( !query.exec( cmd ) )
    {
        db.close();
        return items;
    }

    while ( query.next() )
    {
        QString id = query.value( 0 ).toString();
        QString name = query.value( 1 ).toString();
        QString password = query.value( 2 ).toString();
        QStringList permissions = query.value( 3 ).toString().trimmed().toUpper().split(",");
        HxProfilePtr pProfile = Create(id, name);
        pProfile->SetPassword( password );
        for ( auto &permission : permissions )
            pProfile->SetPermission( permission, true );

        pProfile->ClearModified();
        items.push_back( pProfile );
    }

    db.close();

    return items;
}

HxProfilePtr HxProfileManager::Create( const QString& ID, const QString& name )
{
    auto pProfile = std::make_shared<HxProfile>();
    pProfile->SetID( ID.trimmed().toLower() );
    pProfile->SetName( name.trimmed() );
    pProfile->SetPassword( "123" );
    pProfile->SetPermission( "LEADER", true );
    return pProfile;
}

bool HxProfileManager::Delete( const QString& ID )
{
    return false;
}

bool HxProfileManager::Save( HxProfilePtr pProfile )
{
    return false;
}

void HxProfileManager::Migration( const QString& dir )
{

}

HxProfileManager* ProfileManager()
{
    HxProfileManager instance;
    return &instance;
}