#pragma once
#include <vector>
#include <memory>
#include <set>

#include "QString"

#include "HxObject.h"

class HxProfile;
using HxProfilePtr = std::shared_ptr<HxProfile>;
using HxProfilePtrArray = std::vector<HxProfilePtr>;

class HxProfile : public HxObject
{
    enum ModifyType
    {
        eCreate = 0x01,
        eUpdate = 0x02
    };
public:
    QString name;
    QString pass;
    bool isAdmin = false;
    bool isSuper = true;
    HxProfile();
    ~HxProfile();

    QString ID() const;
    QString Name() const;
    QString Password() const;
    QString Permissions() const;
    bool Permission( const QString& permission ) const;

    void SetID( const QString& ID );
    void SetName( const QString& name );
    void SetPassword( const QString& password );
    void SetPermission( const QString& permission, bool isOn );

private:
    QString m_id;
    QString m_name;
    QString m_password;
    std::set<QString> m_permissions;

public:
    static std::vector<HxProfilePtr> items;
    static void Load();
    static void Save();
};


class HxProfileManager
{
public:
    HxProfileManager();
    void Migration();
    HxProfilePtrArray Profiles();
    HxProfilePtr Create( const QString& ID, const QString& name );
    bool Delete( const QString& ID );
    bool Save( HxProfilePtr pProfile );
    void Migration( const QString& dir );
};

HxProfileManager* ProfileManager();