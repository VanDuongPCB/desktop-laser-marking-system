#include "HxStopper.h"
#include "QCoreApplication"
#include "QDir"
#include "QFile"
#include "QJsonObject"
#include "QJsonArray"
#include "QJsonDocument"

#include "HxFileManager.h"

namespace
{
    HxStopperManager s_instance;
}

HxStopper::HxStopper()
{

}

HxStopper::~HxStopper()
{

}

QMap<int, std::shared_ptr<HxStopper>> HxStopper::items;

void HxStopper::load()
{
    //if ( !items.contains( 1 ) ) items.insert( 1, std::make_shared<HxStopper>( HxStopper() ) );
    //if ( !items.contains( 2 ) ) items.insert( 2, std::make_shared<HxStopper>( HxStopper() ) );
    //if ( !items.contains( 3 ) ) items.insert( 3, std::make_shared<HxStopper>( HxStopper() ) );

    //QString dir = FileManager()->GetPath( HxFileManager::eDBSettingDir );
    //QDir().mkdir( dir );
    //QString path = FileManager()->GetPath( HxFileManager::eDBStopperFile );
    //QFile reader( path );
    //if ( reader.open( QIODevice::ReadOnly ) )
    //{
    //    QByteArray json = reader.readAll();
    //    reader.close();
    //    QJsonDocument doc = QJsonDocument::fromJson( json );
    //    QJsonArray arr = doc.array();
    //    for ( auto arrItem : arr )
    //    {
    //        QJsonObject obj = arrItem.toObject();
    //        int index = obj.value( "index" ).toInt( 0 );
    //        if ( !items.contains( index ) ) continue;
    //        items[ index ]->x = obj.value( "x" ).toDouble( 0 );
    //        items[ index ]->y = obj.value( "y" ).toDouble( 0 );
    //    }
    //}
}

void HxStopper::save()
{
    //QJsonArray arr;
    //for ( int i = 1; i <= 3; i++ )
    //{
    //    if ( !items.contains( i ) ) continue;
    //    QJsonObject obj;
    //    obj.insert( "index", i );
    //    obj.insert( "x", items[ i ]->x );
    //    obj.insert( "y", items[ i ]->y );
    //    arr.push_back( obj );
    //}

    //QJsonDocument doc;
    //doc.setArray( arr );


    //QString dir = FileManager()->GetPath( HxFileManager::eDBSettingDir );
    //QDir().mkdir( dir );
    //QString path = FileManager()->GetPath( HxFileManager::eDBStopperFile );
    //QFile writer( path );
    //if ( writer.open( QIODevice::WriteOnly ) )
    //{
    //    writer.write( doc.toJson() );
    //    writer.close();
    //}
}

std::shared_ptr<HxStopper> HxStopper::find( int index )
{
    if ( items.contains( index ) ) return items[ index ];
    return {};
}

HxStopperPtr HxStopperManager::Create()
{
    return std::make_shared<HxStopper>();
}

HxStopperPtr HxStopperManager::GetStopper( int index )
{
    GetStoppers();
}

HxStopperPtrMap HxStopperManager::GetStoppers()
{
    m_items.clear();
    //for ( int i = 1; i <= 3; i++ )
    //{
    //    auto it = m_items.find( i );
    //    if ( it == m_items.end() )
    //        m_items[ i ] = Create();
    //}

    //QString dir = FileManager()->GetPath( HxFileManager::eDBSettingDir );
    //QDir().mkdir( dir );
    //QString path = FileManager()->GetPath( HxFileManager::eDBStopperFile );
    //QFile reader( path );
    //if ( !reader.open( QIODevice::ReadOnly ) )
    //    return m_items;

    //QByteArray json = reader.readAll();
    //reader.close();
    //QJsonDocument doc = QJsonDocument::fromJson( json );
    //QJsonArray arr = doc.array();
    //for ( auto arrItem : arr )
    //{
    //    QJsonObject obj = arrItem.toObject();
    //    int index = obj.value( "index" ).toInt( 0 );
    //    m_items[ index ]->x = obj.value( "x" ).toDouble( 0 );
    //    m_items[ index ]->y = obj.value( "y" ).toDouble( 0 );
    //}
    return m_items;
}

void HxStopperManager::Save( int index, HxStopperPtr pStopper )
{
    //m_items[ index ] = pStopper;
    //QJsonArray arr;
    //for ( auto& [index, pStopper] : m_items )
    //{
    //    if ( index < 1 || index>3 )
    //        continue;
    //    QJsonObject obj;
    //    obj.insert( "index", index );
    //    obj.insert( "x", pStopper->x );
    //    obj.insert( "y", pStopper->y );
    //    arr.push_back( obj );
    //}

    //QJsonDocument doc;
    //doc.setArray( arr );

    //QString dir = FileManager()->GetPath( HxFileManager::eDBSettingDir );
    //QDir().mkdir( dir );
    //QString path = FileManager()->GetPath( HxFileManager::eDBStopperFile );
    //QFile writer( path );
    //if ( writer.open( QIODevice::WriteOnly ) )
    //{
    //    writer.write( doc.toJson() );
    //    writer.close();
    //}
}

void HxStopperManager::Migration( const QString& dir )
{


}
HxStopperManager* StopperManager()
{
    return &s_instance;
}