#pragma once
#include "HxEvent.h"

HxEvent::HxEvent( HxEvent::Type type ) :
    QEvent( QEvent::Type::User ),
    m_type( type )
{
}

HxEvent::~HxEvent()
{
}

HxEvent::Type HxEvent::GetType() const
{
    return m_type;
}
