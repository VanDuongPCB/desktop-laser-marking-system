#include "HxDesign.h"
#include "QDir"
#include "QFile"
#include "QFileInfo"
#include "QJsonObject"
#include "QJsonArray"
#include "QJsonDocument"
#include "QCoreApplication"

#include "HxFileManager.h"

HxDesign::HxDesign()
{

}

HxDesign::~HxDesign()
{

}

QString HxDesign::Name() const
{
    return m_name;
}

double HxDesign::Width() const
{
    return m_width;
}

double HxDesign::Height() const
{
    return m_height;
}

HxBlock HxDesign::Block( int index )
{
    return m_blocks[ index ];
}

std::map<int, HxBlock> HxDesign::Blocks()
{
    return m_blocks;
}

int HxDesign::IndexOfBlockCode()
{
    if ( m_blocks.empty() )
        return -1;

    int rindex = 1;
    for ( auto& [index, block] : m_blocks )
    {
        if ( block.isCode )
        {
            rindex = index;
            break;
        }
    }
    return rindex;
}


void HxDesign::SetName( const QString& name )
{
    Modify( m_name, name, eName );
}

void HxDesign::SetWidth( double value )
{
    Modify( m_width, value, eSize );
}

void HxDesign::SetHeight( double value )
{
    Modify( m_height, value, eSize );
}

void HxDesign::SetBlock( int index, const HxBlock& block )
{
    m_blocks[ index ] = block;
    SetModified( eBlock );
}

HxDesignPtr HxDesignManager::Create()
{
    return std::make_shared<HxDesign>();
}

HxDesignPtr HxDesignManager::GetDesign( const QString& name )
{
    //HxDesignPtr pDesign;
    //QString designDir = FileManager()->GetPath( HxFileManager::eDBDesignDir );
    //QString designPath = designDir + "/" + name + ".design";
    //QFile fileReader( designPath );
    //if ( !fileReader.open( QIODevice::ReadOnly ) )
    //    return pDesign;

    //QByteArray json = fileReader.readAll();
    //fileReader.close();
    //QJsonDocument doc = QJsonDocument::fromJson( json );
    //QJsonObject obj = doc.object();
    //pDesign = Create();
    //pDesign->SetName( name );

    //pDesign->SetWidth( obj.value( "width" ).toDouble( 5 ) );
    //pDesign->SetHeight( obj.value( "height" ).toDouble( 5 ) );
    //QJsonArray arr = obj.value( "blocks" ).toArray();
    //for ( auto arrItem : arr )
    //{
    //    QJsonObject objBlock = arrItem.toObject();
    //    int index = objBlock.value( "index" ).toInt( 0 );
    //    if ( index < 1 )
    //        continue;
    //    HxBlock block;
    //    block.isCode = objBlock.value( "is-code" ).toBool( false );
    //    block.data = objBlock.value( "data" ).toString();
    //    block.textLen = objBlock.value( "text-length" ).toInt( 1 );
    //    pDesign->SetBlock( index, block );
    //}
    //pDesign->ClearModified();
    //return pDesign;
    return nullptr;
}

HxDesignPtrMap HxDesignManager::GetDesigns()
{
    HxDesignPtrMap map;
    //QString designDir = FileManager()->GetPath( HxFileManager::eDBDesignDir );
    //QDir().mkdir( designDir );
    //for ( int i = 0; i < 2000; i++ )
    //{
    //    QString designName = QString::number( i ).rightJustified( 4, '0' );
    //    HxDesignPtr pDesign = GetDesign( designName );
    //    if ( pDesign )
    //        map[ i ] = pDesign;
    //}

    return map;
}

void HxDesignManager::Save( HxDesignPtr pDesign )
{
    //if ( !pDesign )
    //    return;

    //QString designDir = FileManager()->GetPath( HxFileManager::eDBDesignDir );
    //QDir().mkdir( designDir );

    //QJsonObject objDesign;
    //objDesign.insert( "width", pDesign->Width() );
    //objDesign.insert( "height", pDesign->Height() );

    //QJsonArray arrBlocks;
    //for ( auto& [index, block] : pDesign->Blocks() )
    //{
    //    if ( index < 1 )
    //        continue;
    //    if ( block.data.trimmed().length() == 0 )
    //        continue;
    //    QJsonObject objBlock;
    //    objBlock.insert( "index", index );
    //    objBlock.insert( "is-code", block.isCode );
    //    objBlock.insert( "data", block.data );
    //    objBlock.insert( "text-length", block.textLen );
    //    arrBlocks.push_back( objBlock );
    //}

    //objDesign.insert( "blocks", arrBlocks );
    //QJsonDocument doc;
    //doc.setObject( objDesign );

    //QString designPath = designDir + "/" + pDesign->Name() + ".design";
    //QFile fileWriter( designPath );
    //if ( fileWriter.open( QIODevice::WriteOnly ) )
    //{
    //    fileWriter.write( doc.toJson() );
    //    fileWriter.close();
    //    pDesign->ClearModified();
    //}
}

void HxDesignManager::Migration( const QString& dir )
{

}

HxDesignManager* DesignManager()
{
    static HxDesignManager instance;
    return &instance;
}