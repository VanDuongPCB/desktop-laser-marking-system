#include "HxProtector.h"

#include "QApplication"

#include "HxSettings.h"
#include "HxFileManager.h"
#include "HxEvent.h"

namespace
{
HxProtector s_instance;
}

HxProtector::HxProtector( QObject* parent ) : QObject( parent )
{}

HxProtector::~HxProtector()
{}

bool HxProtector::Login( QString name, QString pass )
{
    auto profiles = ProfileManager()->Profiles();
    for(auto &profile : profiles)
    {
        if ( profile->Name().toLower() != name.toLower() )
            continue;

        if ( profile->Password() == pass )
        {
            m_pProfile = profile;
            if ( profile->Password().isEmpty() )
            {
                profile->SetPassword( pass );
                ProfileManager()->Save( profile );
            }
        }
    }

    qApp->postEvent( qApp, new HxEvent( HxEvent::eLoginEvent ) );

    return m_pProfile != nullptr;
}

void HxProtector::Logout()
{
    m_pProfile.reset();
    qApp->postEvent( qApp, new HxEvent( HxEvent::eLogoutEvent ) );
}

HxProfilePtr HxProtector::Profile()
{
    return m_pProfile;
}

HxProtector* Protector()
{
    static HxProtector instance;
    return &instance;
}
