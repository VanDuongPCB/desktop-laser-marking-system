#pragma once
#include "QObject"
#include "QString"
#include "HxProfile.h"

class HxProtector : public QObject
{
    Q_OBJECT
public:
    explicit HxProtector( QObject* parent = 0 );
    ~HxProtector();
    bool Login( QString name, QString pass );
    void Logout();
    HxProfilePtr Profile();
private:
    HxProfilePtr m_pProfile;
};


HxProtector* Protector();
