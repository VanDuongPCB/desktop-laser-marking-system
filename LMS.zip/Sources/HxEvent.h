#pragma once
#include "QEvent"

class HxEvent : public QEvent
{
public:
    enum Type
    {
        eCustomEvent,
        eLoginEvent,
        eLogoutEvent,
    };
    HxEvent( Type type = eCustomEvent );
    ~HxEvent();
    Type GetType() const;
private:
    Type m_type = eCustomEvent;
};