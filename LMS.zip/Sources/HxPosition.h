#pragma once
struct HxPosition
{
public:
    int index = 0;
    double x = 0;
    double y = 0;
    int angle = 0;
};

