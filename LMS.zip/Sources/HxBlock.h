#pragma once
#include "QString"

class HxBlock
{
public:
    bool isCode = false;
    QString data;
    int textLen = 0;
};
