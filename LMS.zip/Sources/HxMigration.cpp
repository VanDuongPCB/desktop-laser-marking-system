#include "HxMigration.h"
#include "QApplication"
#include "QString"
#include "QFileInfo"

#include "HxLOT.h"
#include "HxModel.h"
#include "HxDesign.h"
#include "HxProfile.h"
#include "HxStopper.h"
#include "HxSettings.h"



HxMigration::HxMigration()
{
}

HxMigration::~HxMigration()
{
}

void HxMigration::Run()
{
    QString databaseFile = "D:/LMS/LMS.db";
    if ( QFileInfo( databaseFile ).exists() )
        return;

    // show

    // copy
    QString databaseDefault = qApp->applicationDirPath() + "/Default Files/LMS.db";
    QFile::copy( databaseDefault, databaseFile );

    // migration
    LOTManager()->Migration("");
    ModelManager()->Migration( "" );
    DesignManager()->Migration( "" );
    StopperManager()->Migration( "" );
    ProfileManager()->Migration( "" );
    //HxLogManager()->Migration( "" );
    //HxSettings

}

HxMigration* Migration()
{
    HxMigration instance;
    return &instance;
}