#pragma once

class HxMigration
{
public:
	HxMigration();
	~HxMigration();
	void Run();
private:

};

HxMigration* Migration();