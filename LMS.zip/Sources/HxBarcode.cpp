
#include "HxBarcode.h"
#include "HxSettings.h"
#include "HxTcpSocket.h"
#include "HxMessage.h"
#include "QCoreApplication"
#include "QTime"
#include "QDir"
#include "QFile"

#include "HxFileManager.h"

bool HxBarcode::IsHasData()
{
    QString cmd = "RD " + HxSettings::barcodeReg + "\r";
    HxTcpSocket sock( HxSettings::plcIp, HxSettings::plcPort );
    sock.Connect();
    sock.WriteLine( cmd, 2000 );
    QString fb = sock.readLine( 2000 );
    return fb == "1";
}

bool HxBarcode::Clear()
{
    QString cmd = "WR " + HxSettings::laserTriggerConfirmReg + " 1\r";
    HxTcpSocket sock( HxSettings::plcIp, HxSettings::plcPort );
    sock.Connect();
    sock.WriteLine( cmd, 2000 );
    QString fb = sock.readLine( 2000 );
    return fb == "OK";
}

QString HxBarcode::Read()
{
    QString cmd = "RDS " + HxSettings::barcodeDataReg + " 40\r";
    HxTcpSocket sock( HxSettings::plcIp, HxSettings::plcPort );
    sock.Connect();
    sock.WriteLine( cmd, 2000 );
    QString fb = sock.readLine( 2000 );
    QStringList codeItems = fb.split( ' ' );
    if ( codeItems.size() < 1 ) 
        return "";
    std::vector<wchar_t> buffer( codeItems.size() + 1, 0 );
    for ( int i = 0; i < codeItems.size(); i++ )
    {
        int val = codeItems[ i ].toInt( 0 );
        buffer[ i ] = ( ( val >> 8 ) | ( val << 8 ) ) & 0xFFFF;
    }

    char* ptr = ( char* )buffer.data();

    return QString::fromStdString( ptr );
}

bool HxBarcode::SendFeedback( bool status )
{
    QString val1 = status == 1 ? "1" : "0";
    QString val2 = status == 1 ? "0" : "1";
    QString cmd = "WRS " + HxSettings::barcodeOKReg + " 2 " + val1 + " " + val2 + "\r";
    HxTcpSocket sock( HxSettings::plcIp, HxSettings::plcPort );
    sock.Connect();
    sock.WriteLine( cmd, 2000 );
    QString fb = sock.readLine( 2000 );
    cmd = "WR " + HxSettings::barcodeConfirmReg + " 1\r";
    sock.WriteLine( cmd, 2000 );
    fb = sock.readLine( 2000 );
    return fb == "OK";
}

void HxBarcode::Save( const QString& code )
{
    //QString dir = FileManager()->GetPath( HxFileManager::eDBBarcodeDir );
    //QDir().mkdir( dir );

    //QString fileName = QDateTime::currentDateTime().toString( "yyyyMMdd" ) + ".csv";
    //QString filePath = dir + "/" + fileName;

    //QFile fileWriter( filePath );
    //if ( !fileWriter.exists() )
    //{
    //    if ( fileWriter.open( QIODevice::WriteOnly ) )
    //    {
    //        fileWriter.write( "TIME,CODE," );
    //        fileWriter.close();
    //    }
    //}

    //QString data = "\n" + QDateTime::currentDateTime().toString( "HH:mm:ss" ) + "," + code + ",";
    //if ( fileWriter.open( QIODevice::WriteOnly | QIODevice::Append | QIODevice::Text ) )
    //{
    //    fileWriter.write( data.toStdString().c_str(), data.length() );
    //    fileWriter.close();
    //}
}


HxBarcode* Barcode()
{
    static HxBarcode instance;
    return &instance;
}
