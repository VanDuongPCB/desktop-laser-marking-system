#pragma once
#include "QString"

class HxLicensing
{
public:
    QString ReadKey();
    void WriteKey( const QString& key );
    bool IsRegistered();
    QString ID();
    QString KeyFromId( const QString& id ) const;
    bool RegisterKey( const QString& key );
    QString GetVersion();

private:
    QString m_Version = "2025.SP0";
    double m_Kernel = 0.202500;
};

HxLicensing* Licensing();
