#pragma once
#include "QString"
#include "QStringList"
#include "QMap"
#include "vector"
#include "memory"
class HxStopper;
using HxStopperPtr = std::shared_ptr<HxStopper>;
using HxStopperPtrMap = std::map<int, HxStopperPtr>;

class HxStopper
{
public:
    double x = -150;
    double y = -127;
    HxStopper();
    ~HxStopper();

public:
    static QMap<int, std::shared_ptr<HxStopper>> items;
    static void load();
    static void save();
    static std::shared_ptr<HxStopper> find( int index );
};

class HxStopperManager
{
public:
    HxStopperPtr Create();
    HxStopperPtr GetStopper( int index );
    HxStopperPtrMap GetStoppers();
    void Save( int index, HxStopperPtr pStopper );
    void Migration( const QString& dir );
private:
    std::map<int, HxStopperPtr> m_items;
};

HxStopperManager* StopperManager();