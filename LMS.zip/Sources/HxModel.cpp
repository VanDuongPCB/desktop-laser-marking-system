#include "HxModel.h"
#include "QFileInfo"
#include "QJsonDocument"
#include "QJsonArray"
#include "QJsonObject"
#include "QStringList"
#include "QDir"
#include "QFile"
#include "QCoreApplication"

#include "HxFileManager.h"

namespace
{
    HxModelManager s_instance;
}
HxModel::HxModel() : HxObject()
{
    m_comments[ "FIX1" ] = "";
    m_comments[ "FIX2" ] = "";
    m_comments[ "FIX3" ] = "";
    m_comments[ "FIX4" ] = "";
    m_comments[ "FIX5" ] = "";
}

HxModel::~HxModel()
{

}

QString HxModel::Code() const
{
    return m_code;
}

QString HxModel::Name() const
{
    return m_name;
}

bool HxModel::IsPrintLo() const
{
    return m_bIsPrintLo;
}

QString HxModel::kNo() const
{
    return m_kNo;
}

QString HxModel::IVProgram() const
{
    return m_ivProgram;
}

QString HxModel::Design() const
{
    return m_design;
}

double HxModel::CvWidth() const
{
    return m_cvWidth;
}

int HxModel::Stopper() const
{
    return m_stopper;
}

std::map<int, HxPosition>& HxModel::Positions()
{
    return m_positions;
}

HxPosition HxModel::Position( int index ) const
{
    auto it = m_positions.find( index );
    if ( it != m_positions.end() )
        return it->second;
    return HxPosition();
}

std::map<QString, QString>& HxModel::Comments()
{
    return m_comments;
}

QString HxModel::Comment( const QString& name ) const
{
    auto it = m_comments.find( name );
    if ( it != m_comments.end() )
        return it->second;
    return QString();
}

QString HxModel::Value( QString paramName ) const
{
    if ( paramName == "CODE" ) return m_code;
    else if ( paramName == "NAME" ) return m_name;
    else if ( paramName == "NO" ) return m_kNo;
    else
    {
        auto it = m_comments.find( paramName );
        if ( it != m_comments.end() )
            return it->second;
        return "MODEL." + paramName;
    }
}

void HxModel::SetCode( const QString& value )
{
    Modify( m_code, value, eCode );
}

void HxModel::SetName( const QString& value )
{
    Modify( m_name, value, eOther );
}

void HxModel::SetPrintLo( bool bIsEnable )
{
    Modify( m_bIsPrintLo, bIsEnable, eOther );
}

void HxModel::SetkNo( const QString& value )
{
    Modify( m_kNo, value, eOther );
}

void HxModel::SetIVProgram( const QString& value )
{
    Modify( m_ivProgram, value, eOther );
}

void HxModel::SetDesign( const QString& value )
{
    Modify( m_design, value, eOther );
}

void HxModel::SetDesign( size_t value )
{
    SetDesign( QString::number( value ).rightJustified( 4, '0' ) );
}

void HxModel::SetCvWidth( double value )
{
    Modify( m_cvWidth, value, eOther );
}

void HxModel::SetStopper( int value )
{
    Modify( m_stopper, value, eOther );
}

void HxModel::SetPositions( const std::map<int, HxPosition>& value )
{
    m_positions = value;
    SetModified( eOther );
}

void HxModel::SetPosition( int index, const HxPosition& value )
{
    m_positions[ index ] = value;
    SetModified( eOther );
}

void HxModel::RemovePosition( int index )
{
    m_positions.erase( index );
    SetModified( eOther );
}

void HxModel::SetComments( const std::map<QString, QString>& comments )
{
    m_comments = comments;
    SetModified( eOther );
}

void HxModel::SetComment( const QString& key, const QString& value )
{
    m_comments[ key.trimmed().toUpper() ] = value;
    SetModified( eOther );
}

void HxModel::AddComments( const QStringList& keys )
{
    for ( auto& key : keys )
    {
        auto it = m_comments.find( key.trimmed().toUpper() );
        if ( it == m_comments.end() )
        {
            m_comments[ key.trimmed().toUpper() ] = "";
            SetModified( eOther );
        }
    }
}

void HxModel::RemoveComments( const QStringList& keys )
{
    for ( auto& key : keys )
    {
        auto it = m_comments.find( key );
        if ( it != m_comments.end() )
        {
            m_comments.erase( key );
            SetModified( eOther );
        }

        it = m_comments.find( key.trimmed().toUpper() );
        if ( it != m_comments.end() )
        {
            m_comments.erase( key.trimmed().toUpper() );
            SetModified( eOther );
        }
    }
}

void HxModel::SetValue( const QString& key, const QString& value )
{
    m_comments[ key.trimmed().toUpper() ] = value;
    SetModified( eOther );
}

QStringList HxModel::paramNames()
{
    QStringList names = { "NAME","CODE","NO","FIX1","FIX2","FIX3","FIX4","FIX5" };
    // for ( auto& it : items )
    // {
    //     for ( auto& [key, value] : it->m_comments )
    //     {
    //         if ( names.contains( key ) == false )
    //         {
    //             names.push_back( key );
    //         }
    //     }
    // }
    return names;
}

HxModelPtr HxModelManager::Create( const QString& code, const QString& name )
{
    auto pModel = std::make_shared<HxModel>();
    pModel->SetCode( code );
    pModel->SetName( name );
    return pModel;
}

QStringList HxModelManager::Names()
{
    QStringList items;
    //QString modelDir = FileManager()->GetPath( HxFileManager::eDBModelDir );
    //QDir().mkdir( modelDir );
    //QFileInfoList files = QDir( modelDir ).entryInfoList( { "*.model" } );
    //for ( auto& file : files )
    //{
    //    items.push_back( file.baseName().toUpper() );
    //}
    return items;
}

QStringList HxModelManager::ParamNames()
{
    QStringList items;
    return items;
}

HxModelPtrMap HxModelManager::GetModels()
{
    HxModelPtrMap map;
    //QString modelDir = FileManager()->GetPath( HxFileManager::eDBModelDir );
    //QDir().mkdir( modelDir );
    //QFileInfoList files = QDir( modelDir ).entryInfoList( { "*.model" } );

    //for ( auto& file : files )
    //{
    //    QFile reader( file.absoluteFilePath() );
    //    if ( !reader.open( QIODevice::ReadOnly ) )
    //        continue;

    //    HxModelPtr pModel = Create();
    //    QByteArray json = reader.readAll();
    //    reader.close();

    //    QJsonDocument doc = QJsonDocument::fromJson( json );
    //    QJsonObject obj = doc.object();

    //    pModel->SetCode( obj.value( "code" ).toString() );
    //    pModel->SetName( file.baseName().toUpper() );
    //    pModel->SetPrintLo( obj.value( "is-print-lo" ).toBool() );
    //    pModel->SetkNo( obj.value( "k-no" ).toString() );
    //    pModel->SetIVProgram( obj.value( "iv-program" ).toString() );
    //    pModel->SetDesign( obj.value( "design" ).toString() );
    //    pModel->SetCvWidth( obj.value( "cv-width" ).toDouble() );
    //    pModel->SetStopper( obj.value( "stopper" ).toInt( 1 ) );

    //    // markPositions;
    //    QJsonArray posArr = obj.value( "pos" ).toArray();
    //    int posIndex = 1;
    //    for ( auto posItem : posArr )
    //    {
    //        QJsonObject objPos = posItem.toObject();
    //        HxPosition pos;
    //        pos.index = objPos.value( "index" ).toInt();
    //        if ( pos.index <= 0 )
    //            pos.index = posIndex;
    //        pos.x = objPos.value( "x" ).toDouble( 0 );
    //        pos.y = objPos.value( "y" ).toDouble( 0 );
    //        pos.angle = objPos.value( "angle" ).toDouble( 0 );

    //        pModel->SetPosition( pos.index, pos );
    //        posIndex++;
    //    }

    //    // comments;
    //    QJsonObject commentObj = obj.value( "comments" ).toObject();
    //    QStringList keys = commentObj.keys();
    //    for ( auto& key : keys )
    //    {
    //        pModel->SetComment( key, commentObj.value( key ).toString() );
    //    }

    //    pModel->ClearModified();
    //    QString modeName = file.baseName().toUpper();
    //    map[ modeName ] = pModel;
    //}
    return map;
}

HxModelPtr HxModelManager::GetModel( const QString& name )
{
    //HxModelPtr pModel;
    //if ( name.isEmpty() )
    //    return pModel;

    //QString modelDir = GetFileManager()->GetPath( HxFileManager::eDBModelDir );
    //QDir().mkdir( modelDir );
    //QString modelFile = QString( "%1/%2.model" ).arg( modelDir ).arg( name );

    //QFile reader( modelFile );
    //if ( !reader.open( QIODevice::ReadOnly ) )
    //    return pModel;

    //QByteArray json = reader.readAll();
    //reader.close();

    //QJsonDocument doc = QJsonDocument::fromJson( json );
    //QJsonObject obj = doc.object();

    //if ( !pModel )
    //    pModel = Create( "", name );

    //pModel->SetCode( obj.value( "code" ).toString() );
    //pModel->SetName( name.toUpper() );
    //pModel->SetPrintLo( obj.value( "is-print-lo" ).toBool() );
    //pModel->SetkNo( obj.value( "k-no" ).toString() );
    //pModel->SetIVProgram( obj.value( "iv-program" ).toString() );
    //pModel->SetDesign( obj.value( "design" ).toString() );
    //pModel->SetCvWidth( obj.value( "cv-width" ).toDouble() );
    //pModel->SetStopper( obj.value( "stopper" ).toInt( 1 ) );

    //// markPositions;
    //QJsonArray posArr = obj.value( "pos" ).toArray();
    //int posIndex = 1;
    //for ( auto posItem : posArr )
    //{
    //    QJsonObject objPos = posItem.toObject();
    //    HxPosition pos;
    //    pos.index = objPos.value( "index" ).toInt();
    //    if ( pos.index <= 0 )
    //        pos.index = posIndex;
    //    pos.x = objPos.value( "x" ).toDouble( 0 );
    //    pos.y = objPos.value( "y" ).toDouble( 0 );
    //    pos.angle = objPos.value( "angle" ).toDouble( 0 );

    //    pModel->SetPosition( pos.index, pos );
    //    posIndex++;
    //}

    //// comments;
    //QJsonObject commentObj = obj.value( "comments" ).toObject();
    //QStringList keys = commentObj.keys();
    //for ( auto& key : keys )
    //{
    //    pModel->SetComment( key, commentObj.value( key ).toString() );
    //}

    //pModel->ClearModified();
    //return pModel;
    return nullptr;
}

void HxModelManager::Save( HxModelPtr pModel )
{
    //if ( !pModel )
    //    return;
    //QJsonObject obj;
    //// common
    //obj.insert( "code", pModel->Code() );
    //obj.insert( "is-print-lo", pModel->IsPrintLo() );
    //obj.insert( "cv-width", pModel->CvWidth() );
    //obj.insert( "stopper", pModel->Stopper() );
    //obj.insert( "iv-program", pModel->IVProgram() );
    //obj.insert( "design", pModel->Design() );
    //obj.insert( "k-no", pModel->kNo() );

    //// pos
    //QJsonArray posArr;
    //auto positions = pModel->Positions();
    //for ( auto& [index, pos] : positions )
    //{
    //    QJsonObject posObj;
    //    posObj.insert( "index", index );
    //    posObj.insert( "x", pos.x );
    //    posObj.insert( "y", pos.y );
    //    posObj.insert( "angle", pos.angle );
    //    posArr.push_back( posObj );
    //}
    //obj.insert( "pos", posArr );

    //// comments
    //QJsonObject commentObj;
    //auto comments = pModel->Comments();
    //for ( auto& [key, value] : comments )
    //{
    //    commentObj.insert( key, value );
    //}
    //obj.insert( "comments", commentObj );
    //QJsonDocument doc;
    //doc.setObject( obj );

    //QString dir = GetFileManager()->GetPath( HxFileManager::eDBModelDir );
    //QDir().mkdir( dir );
    //QString path = dir + "/" + pModel->Name() + ".model";
    //QFile writer( path );
    //if ( writer.open( QIODevice::WriteOnly ) )
    //{
    //    writer.write( doc.toJson() );
    //    writer.close();
    //}

    //pModel->ClearModified();
}

void HxModelManager::Removes( const QStringList& names )
{
    //for ( auto& name : names )
    //{
    //    QString dir = FileManager()->GetPath( HxFileManager::eDBModelDir );
    //    QDir().mkdir( dir );
    //    QString path = dir + "/" + name + ".model";
    //    QFile::remove( path );
    //}
}

void HxModelManager::AddComments( const QStringList& keys )
{

}

void HxModelManager::RemoveComments( const QStringList& keys )
{

}

void HxModelManager::Migration( const QString& dir )
{

}

HxModelManager* ModelManager()
{
    return &s_instance;
}
